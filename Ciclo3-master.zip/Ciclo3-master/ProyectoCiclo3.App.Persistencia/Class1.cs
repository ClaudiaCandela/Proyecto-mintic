﻿using System;

namespace ProyectoCiclo3.App.Persistencia
{
    public class Class1
    {
    }
}
