﻿using System;

namespace ProyectoCiclo3.App.Dominio
{
    public class Class1
    {
    }
}
