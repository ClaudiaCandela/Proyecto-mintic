using System;
namespace ProyectoCiclo3.App.Dominio{
    public class Rutas{
        public int id {get;set;}
        public int origen {get; set;}
        public int destino {get; set;}
        public int tiempo_estimado {get; set;} 
    }
}